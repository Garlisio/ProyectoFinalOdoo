# -*- coding: utf-8 -*-

from odoo import models, fields

class ContractingCompany(models.Model):
    _name = 'pm.contracting_company'
    _description = 'Contracting Company'

    name = fields.Char(required=True)
    projects_ids = fields.One2many('pm.project', 'company_id', string='Projects')

class Project(models.Model):
    _name = 'pm.project'
    _description = 'Project'

    name = fields.Char(required=True)
    company_id = fields.Many2one('pm.contracting_company', string='Contracting Company')
    task_ids = fields.One2many('pm.task', 'project_id', string='Tasks')

class Task(models.Model):
    _name = 'pm.task'
    _description = 'Task'

    name = fields.Char(required=True)
    project_id = fields.Many2one('pm.project', string='Project')
    subtask_ids = fields.One2many('pm.subtask', 'task_id', string='Subtasks')

class Subtask(models.Model):
    _name = 'pm.subtask'
    _description = 'Subtask'

    name = fields.Char(required=True)
    task_id = fields.Many2one('pm.task', string='Task')
