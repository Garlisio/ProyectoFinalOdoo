# -*- coding: utf-8 -*-

{
    'name': 'Project Management',
    'version': '1.0',
    'category': 'Project',
    'summary': 'Standalone Project Management for Software Development Company',
    'depends': ['base'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/views.xml',
        'data/demo_data.xml',
    ],
    'installable': True,
    'application': True,

    # assets 
    'assets': {
        'web.assets_common': [
            'project_manager/static/src/scss/style1.scss',
        ]
    }
}